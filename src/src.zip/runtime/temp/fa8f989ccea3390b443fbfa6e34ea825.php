<?php /*a:1:{s:32:"/project/view/index/welcome.html";i:1642471920;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="description" content="EasyAdmin - 一款基于ThinkPHP6.0和Layui的快速开发的后台管理框架系统">
    <meta name="author" content="EasyAdmin">
    <meta name="keywords" content="EasyAdmin,EasyAdmin官网,thinkphp6.0框架,layui前端框架,后台快速开发框架,php框架">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <title>EasyAdmin | 一款基于ThinkPHP6.0和Layui的快速开发的后台管理框架系统</title>
    <link rel="stylesheet" href="/static/common/css/welcome.css?v=<?php echo htmlentities($version); ?>">
</head>
<body>
<div id='app'>
    <!-- 头部-->
    <header>
        <!-- logo -->
        <p class="left logo-box">
            <i class="img-logo-header logo"></i>
            <a href="http://easyadmin.99php.cn">EasyAdmin</a>
        </p>
        <div class="right">
            <!-- 导航-->
            <div class="navbar">
                <?php foreach($navbar as $vo): ?>
                <a class="navbar-item <?php if($vo['active']===true): ?>active<?php endif; ?>" href="<?php echo htmlentities($vo['href']); ?>" target="<?php echo htmlentities($vo['target']); ?>"><?php echo htmlentities($vo['name']); ?></a>
                <?php endforeach; ?>
            </div>
            <!-- git统计-->
            <div class="github-btns">
                <iframe class="star-btn" src="https://ghbtns.com/github-btn.html?user=zhongshaofa&repo=easyadmin&type=star&count=true"></iframe>
                <iframe class="fork-btn" src="https://ghbtns.com/github-btn.html?user=zhongshaofa&repo=easyadmin&type=fork&count=true"></iframe>
            </div>
        </div>
    </header>

    <div class="home-main">
        <div class="title">
            <p><i class="name img-name"></i></p>
            <p class="desc"><?php echo htmlentities((isset($data['description']) && ($data['description'] !== '')?$data['description']:'')); ?></p>
            <p class="operation">
                <a class="start" target="_blank" href="http://easyadmin.99php.cn/docs"> 起步 <i class="icon-play"></i></a>
                <a class="github button-grya" target="_blank" href="https://github.com/zhongshaofa/easyadmin"><i class="icon-github-big"></i>GitHub</a>
                <a class="gitee button-grya" target="_blank" href="https://gitee.com/zhongshaofa/easyadmin"><i class="icon-gitee"></i>Gitee</a>
            </p>
        </div>
        <!-- 框架特性-->
        <div class="introduction">
            <!-- 特性标题-->
            <div class="top">
                <div class="part-title">
                    <p class="text">系统描述</p>
                    <p class="line"></p>
                </div>
                <p class="part-desc">
                    <?php echo htmlentities((isset($data['system_description']) && ($data['system_description'] !== '')?$data['system_description']:'')); ?>
                </p>
            </div>
            <!-- 特性介绍-->
            <div class="bottom">
                <?php foreach($feature as $vo): ?>
                <div class="item">
                    <p class="item-title"><span><?php echo htmlentities($vo['name']); ?></span></p>
                    <p class="item-desc"><?php echo htmlentities($vo['description']); ?></p>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
    
        <div class="introduction">
        <!-- 特性标题-->
        <div class="top">
            <div class="part-title">
                <p class="text">免责声明</p>
                <p class="line"></p>
            </div>
            <p class="part-desc">
                任何用户在使用`EasyAdmin`后台框架前，请您仔细阅读并透彻理解本声明。您可以选择不使用`EasyAdmin`后台框架，若您一旦使用`EasyAdmin`后台框架，您的使用行为即被视为对本声明全部内容的认可和接受。
            </p>
        </div>
        <!-- 特性介绍-->
        <div class="bottom">
            <p class="item-desc"> `EasyAdmin`后台框架是一款开源免费的后台快速开发框架 ，主要用于更便捷地开发后台管理；其尊重并保护所有用户的个人隐私权，不窃取任何用户计算机中的信息。更不具备用户数据存储等网络传输功能。</p>
            <p class="item-desc"> 您承诺秉着合法、合理的原则使用`EasyAdmin`后台框架，不利用`EasyAdmin`后台框架进行任何违法、侵害他人合法利益等恶意的行为，亦不将`EasyAdmin`后台框架运用于任何违反我国法律法规的 Web 平台。</p>
            <p class="item-desc">任何单位或个人因下载使用`EasyAdmin`后台框架而产生的任何意外、疏忽、合约毁坏、诽谤、版权或知识产权侵犯及其造成的损失 (包括但不限于直接、间接、附带或衍生的损失等)，本开源项目不承担任何法律责任。</p>
            <p class="item-desc">用户明确并同意本声明条款列举的全部内容，对使用`EasyAdmin`后台框架可能存在的风险和相关后果将完全由用户自行承担，本开源项目不承担任何法律责任。</p>
            <p class="item-desc">任何单位或个人在阅读本免责声明后，应在《MIT 开源许可证》所允许的范围内进行合法的发布、传播和使用`EasyAdmin`后台框架等行为，若违反本免责声明条款或违反法律法规所造成的法律责任(包括但不限于民事赔偿和刑事责任），由违约者自行承担。</p>
            <p class="item-desc">如果本声明的任何部分被认为无效或不可执行，其余部分仍具有完全效力。不可执行的部分声明，并不构成我们放弃执行该声明的权利。</p>
            <p class="item-desc">本开源项目有权随时对本声明条款及附件内容进行单方面的变更，并以消息推送、网页公告等方式予以公布，公布后立即自动生效，无需另行单独通知；若您在本声明内容公告变更后继续使用的，表示您已充分阅读、理解并接受修改后的声明内容。</p>

        </div>
    </div>
</div>

    <!-- 底部-->
    <footer class="site-footer">
        <div class="container">
            <p class="protocol">遵循 Apache-2.0 开源协议 </p>
            <p class="beian-number">Copyright © （填你自己的）版权所有，并保留所有权利 | <a target="_blank" href="http://www.miitbeian.gov.cn">（填你自己的）</a></p>
            <p>Site designed by <a href="https://github.com/zhongshaofa" target="_blank">zhongshaofa</a></p>
        </div>
    </footer>
</div>
</body>
</html>
