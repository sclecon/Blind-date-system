<?php
//000000003600
 exit();?>
s:49:"doc,gif,ico,icon,jpg,mp3,mp4,p12,pem,png,rar,jpeg";