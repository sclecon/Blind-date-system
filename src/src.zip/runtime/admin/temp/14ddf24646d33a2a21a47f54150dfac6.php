<?php /*a:2:{s:38:"/project/app/admin/view/user/edit.html";i:1642471919;s:43:"/project/app/admin/view/layout/default.html";i:1642471919;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo sysconfig('site','site_name'); ?></title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <!--[if lt IE 9]>
    <script src="https://cdn.staticfile.org/html5shiv/r29/html5.min.js"></script>
    <script src="https://cdn.staticfile.org/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <link rel="stylesheet" href="/static/admin/css/public.css?v=<?php echo htmlentities($version); ?>" media="all">
    <script>
        window.CONFIG = {
            ADMIN: "<?php echo htmlentities((isset($adminModuleName) && ($adminModuleName !== '')?$adminModuleName:'admin')); ?>",
            CONTROLLER_JS_PATH: "<?php echo htmlentities((isset($thisControllerJsPath) && ($thisControllerJsPath !== '')?$thisControllerJsPath:'')); ?>",
            ACTION: "<?php echo htmlentities((isset($thisAction) && ($thisAction !== '')?$thisAction:'')); ?>",
            AUTOLOAD_JS: "<?php echo htmlentities((isset($autoloadJs) && ($autoloadJs !== '')?$autoloadJs:'false')); ?>",
            IS_SUPER_ADMIN: "<?php echo htmlentities((isset($isSuperAdmin) && ($isSuperAdmin !== '')?$isSuperAdmin:'false')); ?>",
            VERSION: "<?php echo htmlentities((isset($version) && ($version !== '')?$version:'1.0.0')); ?>",
            CSRF_TOKEN: "<?php echo token(); ?>",
        };
    </script>
    <script src="/static/plugs/layui-v2.5.6/layui.all.js?v=<?php echo htmlentities($version); ?>" charset="utf-8"></script>
    <script src="/static/plugs/require-2.3.6/require.js?v=<?php echo htmlentities($version); ?>" charset="utf-8"></script>
    <script src="/static/config-admin.js?v=<?php echo htmlentities($version); ?>" charset="utf-8"></script>
</head>
<body>
<div class="layuimini-container">
    <form id="app-form" class="layui-form layuimini-form">
        
        <div class="layui-form-item">
            <label class="layui-form-label">用户UID</label>
            <div class="layui-input-block">
                <input type="text" name="user_id" class="layui-input" lay-verify="required" placeholder="请输入用户UID" value="<?php echo htmlentities((isset($row['user_id']) && ($row['user_id'] !== '')?$row['user_id']:'')); ?>">
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">用户名</label>
            <div class="layui-input-block">
                <input type="text" name="username" class="layui-input" lay-verify="required" placeholder="请输入用户名" value="<?php echo htmlentities((isset($row['username']) && ($row['username'] !== '')?$row['username']:'')); ?>">
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">手机号</label>
            <div class="layui-input-block">
                <input type="text" name="phone" class="layui-input" lay-verify="required" placeholder="请输入手机号" value="<?php echo htmlentities((isset($row['phone']) && ($row['phone'] !== '')?$row['phone']:'')); ?>">
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label required">头像照片 最多五张</label>
            <div class="layui-input-block layuimini-upload">
                <input name="avatar" class="layui-input layui-col-xs6"   placeholder="请上传头像照片 最多五张" value="<?php echo htmlentities((isset($row['avatar']) && ($row['avatar'] !== '')?$row['avatar']:'')); ?>">
                <div class="layuimini-upload-btn">
                    <span><a class="layui-btn" data-upload="avatar" data-upload-number="more" data-upload-exts="png|jpg|ico|jpeg" data-upload-icon="image" data-upload-sign=""><i class="fa fa-upload"></i> 上传</a></span>
                    <span><a class="layui-btn layui-btn-normal" id="select_avatar" data-upload-select="avatar" data-upload-number="more" data-upload-mimetype="image/*" data-upload-sign=""><i class="fa fa-list"></i> 选择</a></span>
                </div>
            </div>
        </div>
        <div class="layui-form-item layui-form-text">
            <label class="layui-form-label">个人介绍</label>
            <div class="layui-input-block">
                <textarea name="remark" class="layui-textarea"  placeholder="请输入个人介绍"><?php echo (isset($row['remark']) && ($row['remark'] !== '')?$row['remark']:''); ?></textarea>
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">经度</label>
            <div class="layui-input-block">
                <input type="text" name="longitude" class="layui-input"  placeholder="请输入经度" value="<?php echo htmlentities((isset($row['longitude']) && ($row['longitude'] !== '')?$row['longitude']:'')); ?>">
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">维度</label>
            <div class="layui-input-block">
                <input type="text" name="dimension" class="layui-input"  placeholder="请输入维度" value="<?php echo htmlentities((isset($row['dimension']) && ($row['dimension'] !== '')?$row['dimension']:'')); ?>">
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">学历</label>
            <div class="layui-input-block">
                <?php foreach($getEduList as $k=>$v): ?>
                <input type="radio" name="edu" value="<?php echo htmlentities($k); ?>" title="<?php echo htmlentities($v); ?>" <?php if(in_array(($k), is_array($row['edu'])?$row['edu']:explode(',',$row['edu']))): ?>checked=""<?php endif; ?>>
                <?php endforeach; ?>
            </div>
        </div>

        <div class="layui-form-item">
            <label class="layui-form-label">性别</label>
            <div class="layui-input-block">
                <?php foreach($getSexList as $k=>$v): ?>
                <input type="radio" name="sex" value="<?php echo htmlentities($k); ?>" title="<?php echo htmlentities($v); ?>" <?php if(in_array(($k), is_array($row['sex'])?$row['sex']:explode(',',$row['sex']))): ?>checked=""<?php endif; ?>>
                <?php endforeach; ?>
            </div>
        </div>

        <div class="layui-form-item">
            <label class="layui-form-label">生日</label>
            <div class="layui-input-block">
                <input type="text" name="birthday" class="layui-input"  placeholder="请输入生日" value="<?php echo htmlentities((isset($row['birthday']) && ($row['birthday'] !== '')?$row['birthday']:'')); ?>">
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">身高</label>
            <div class="layui-input-block">
                <input type="text" name="height" class="layui-input"  placeholder="请输入身高" value="<?php echo htmlentities((isset($row['height']) && ($row['height'] !== '')?$row['height']:'')); ?>">
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">城市</label>
            <div class="layui-input-block">
                <input type="text" name="city" class="layui-input"  placeholder="请输入城市" value="<?php echo htmlentities((isset($row['city']) && ($row['city'] !== '')?$row['city']:'')); ?>">
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">居住地</label>
            <div class="layui-input-block">
                <input type="text" name="address" class="layui-input"  placeholder="请输入居住地" value="<?php echo htmlentities((isset($row['address']) && ($row['address'] !== '')?$row['address']:'')); ?>">
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">婚姻状况</label>
            <div class="layui-input-block">
                <?php foreach($getMarriageList as $k=>$v): ?>
                <input type="radio" name="marriage" value="<?php echo htmlentities($k); ?>" title="<?php echo htmlentities($v); ?>" <?php if(in_array(($k), is_array($row['marriage'])?$row['marriage']:explode(',',$row['marriage']))): ?>checked=""<?php endif; ?>>
                <?php endforeach; ?>
            </div>
        </div>

        <div class="layui-form-item">
            <label class="layui-form-label">子女状况</label>
            <div class="layui-input-block">
                <?php foreach($getChildrenList as $k=>$v): ?>
                <input type="radio" name="children" value="<?php echo htmlentities($k); ?>" title="<?php echo htmlentities($v); ?>" <?php if(in_array(($k), is_array($row['children'])?$row['children']:explode(',',$row['children']))): ?>checked=""<?php endif; ?>>
                <?php endforeach; ?>
            </div>
        </div>

        <div class="layui-form-item">
            <label class="layui-form-label">籍贯</label>
            <div class="layui-input-block">
                <input type="text" name="native" class="layui-input"  placeholder="请输入籍贯" value="<?php echo htmlentities((isset($row['native']) && ($row['native'] !== '')?$row['native']:'')); ?>">
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">民族</label>
            <div class="layui-input-block">
                <input type="text" name="nation" class="layui-input"  placeholder="请输入民族" value="<?php echo htmlentities((isset($row['nation']) && ($row['nation'] !== '')?$row['nation']:'')); ?>">
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">血型</label>
            <div class="layui-input-block">
                <?php foreach($getBloodList as $k=>$v): ?>
                <input type="radio" name="blood" value="<?php echo htmlentities($k); ?>" title="<?php echo htmlentities($v); ?>" <?php if(in_array(($k), is_array($row['blood'])?$row['blood']:explode(',',$row['blood']))): ?>checked=""<?php endif; ?>>
                <?php endforeach; ?>
            </div>
        </div>

        <div class="layui-form-item">
            <label class="layui-form-label">体重</label>
            <div class="layui-input-block">
                <input type="text" name="weight" class="layui-input"  placeholder="请输入体重" value="<?php echo htmlentities((isset($row['weight']) && ($row['weight'] !== '')?$row['weight']:'')); ?>">
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">职业</label>
            <div class="layui-input-block">
                <input type="text" name="occupation" class="layui-input"  placeholder="请输入职业" value="<?php echo htmlentities((isset($row['occupation']) && ($row['occupation'] !== '')?$row['occupation']:'')); ?>">
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">毕业学校</label>
            <div class="layui-input-block">
                <input type="text" name="school" class="layui-input"  placeholder="请输入毕业学校" value="<?php echo htmlentities((isset($row['school']) && ($row['school'] !== '')?$row['school']:'')); ?>">
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">所学专业</label>
            <div class="layui-input-block">
                <input type="text" name="major" class="layui-input"  placeholder="请输入所学专业" value="<?php echo htmlentities((isset($row['major']) && ($row['major'] !== '')?$row['major']:'')); ?>">
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">购房情况</label>
            <div class="layui-input-block">
                <?php foreach($getHouseList as $k=>$v): ?>
                <input type="radio" name="house" value="<?php echo htmlentities($k); ?>" title="<?php echo htmlentities($v); ?>" <?php if(in_array(($k), is_array($row['house'])?$row['house']:explode(',',$row['house']))): ?>checked=""<?php endif; ?>>
                <?php endforeach; ?>
            </div>
        </div>

        <div class="layui-form-item">
            <label class="layui-form-label">购车情况</label>
            <div class="layui-input-block">
                <?php foreach($getCarBuyList as $k=>$v): ?>
                <input type="radio" name="car_buy" value="<?php echo htmlentities($k); ?>" title="<?php echo htmlentities($v); ?>" <?php if(in_array(($k), is_array($row['car_buy'])?$row['car_buy']:explode(',',$row['car_buy']))): ?>checked=""<?php endif; ?>>
                <?php endforeach; ?>
            </div>
        </div>

        <div class="layui-form-item">
            <label class="layui-form-label">会员状态</label>
            <div class="layui-input-block">
                <input type="text" name="status" class="layui-input" lay-verify="required" placeholder="请输入会员状态" value="<?php echo htmlentities((isset($row['status']) && ($row['status'] !== '')?$row['status']:'')); ?>">
            </div>
        </div>
        <div class="hr-line"></div>
        <div class="layui-form-item text-center">
            <button type="submit" class="layui-btn layui-btn-normal layui-btn-sm" lay-submit>确认</button>
            <button type="reset" class="layui-btn layui-btn-primary layui-btn-sm">重置</button>
        </div>

    </form>
</div>
</body>
</html>