<?php

return [

    // 自动加载，插件命令行模式下必须
    'autoload'       => true,

    // 默认插件入口路径
    'path'           => 'addons',

    // 默认方法
    'default_action' => 'index',

];